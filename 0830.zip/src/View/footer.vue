<template>
  <div>
    <ul class="btm_btn clfix">
      <li class="home"><router-link to="/"></router-link></li>
      <li class="back" @click="RouterBack"><a></a></li>
      <li class="go" @click="RouterGo"><a></a></li>
      <li class="btm_menu"><a></a></li>
      <li class="btm_organ" @click="orgClick()"><a></a></li>
      <li class="btm_allim">
        <a><em class="allim_num">23</em></a>
      </li>
    </ul>
    <div class="btm_menu_list">
      <div class="list_inner">
        <ul class="clfix">
          <li v-for="(value, name) in mainmenu" :key="name">
            <router-link :to="`/${value.key}_more`"
              ><span :class="`${value.key}_f_ic`"></span
              >{{ GetMainLanguage.header[value.key] }}</router-link
            >
          </li>
        </ul>
        <em class="close_btn"></em>
      </div>
    </div>
    <div class="all_organ_modal" :class="{ on: this.modalon }">
      <!--위치 수정됨-->
      <div class="organ_con">
        <form>
          <div>
            <strong>조직도</strong>
            <div>
              <input
                type="text"
                class="search"
                placeholder="검색어를 입력하세요"
                autocomplete="on"
                @keyup="OrgSearch($event.target.value)"
              />
              <div class="btns">
                <span class="del_btn"><em></em></span>
                <span class="search_icon" @click="SetAutoOrg"
                  ><img src="../mobile/img/search_icon.png" alt="검색하기"
                /></span>
              </div>
            </div>
          </div>
          <ul class="organlist">
            <span
              class=""
              v-for="(value, name) in this.GetMail.org.trans"
              :key="name"
            >
              <org-item
                :item="value"
                :modalAutoOrg="modalAutoOrg"
                @OpenFolder="OpenFolder"
              ></org-item>
            </span>
          </ul>
        </form>
        <span class="modal_close" @click="ModalOff"></span>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState, mapGetters } from "vuex";
import OrgItem from "../components/mail/orgitemview.vue";
export default {
  computed: {
    ...mapState("mailjs", ["mail", "mailorg"]),
    ...mapGetters("mailjs", ["GetMailDetail", "GetMail", "GetMailConfig"]),
    ...mapGetters(["GetMainLanguage"]),
    path() {
      return this.$route.path.substring(this.$route.path.lastIndexOf("/") + 1);
    },
  },
  components: {
    OrgItem,
  },
  data: function () {
    return {
      modalAutoOrg: 0,
      modalon: false,
    };
  },
  beforeDestroy() {
    console.log("destroy");
    this.$store.commit("mailjs/From", "");
    this.$store.commit("mailjs/MailOrgDataInit");
  },
  methods: {
    ModalOff() {
      this.modalon = false;
    },
    OpenFolder() {},
    OrgSearch(value) {
      if (value.length >= 2) {
        var data = {};
        data.menu = "mail";
        data.keyword = value;
        data.who = this.mailorg.pointer;
        this.$store.dispatch("OrgAutoSearch", data);
      }
    },
    // 전 url 이동
    RouterBack() {
      this.$store.commit("mailjs/Back");
      this.$router.go(-1);
    },
    // 후 url 이동
    RouterGo() {
      this.$store.commit("mailjs/Back");

      this.$router.go(1);
    },
    // 새로고침
    RouterRefresh() {
      this.$router.push(this.$route.path);
    },
    RouterLink() {
      console.log("routerlink");
    },
    SetAutoOrg() {
      this.modalAutoOrg += 1;
    },
    orgClick(to) {
      this.modalon = true;
    },
  },
};
</script>

<style>
</style>