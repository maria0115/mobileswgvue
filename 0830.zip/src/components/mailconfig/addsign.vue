<template>
  <div>
    <h2 class="mail_st_header">
      <router-link to="sign">
        <img src="../../mobile/img/wmail_back.png" alt="" /> </router-link
      >서명 등록
      <span class="save" @click="SignAdd"><a>저장</a></span>
    </h2>
    <div class="m_contents06">
      <form action="">
        <ul>
          <li>
            <span>제목</span>
            <input type="text" v-model="subject" />
          </li>
          <li>
            <span>설정</span>
            <div @click="DefaultSign"><em class="sig_check"  :class="{active:this.default}"></em>기본 서명으로 지정</div>
          </li>
          <li>
            <textarea v-model="body">
---------------------------------------------------------
이정인 책임연구원
(주)새롬정보시스템/디자인팀
153-704 서울시 금천구 가산디지털1로 219 벽산디지털 밸리 
6차 601호 
Tel : (02) 2105-2548  H.P: 010-6612-5764
E-mail : jeongin@saerom.co.kr
http://www.saerom.co.kr
---------------------------------------------------------
                    </textarea
            >
          </li>
        </ul>
      </form>
    </div>
  </div>
</template>

<script>
export default {
  components: {
  },
  data() {
    return {
      // path:this.path,
      subject: "",
      default: false,
      body: "",
    };
  },
  methods: {
    DefaultSign(){
      this.default = !this.default;
    },
    SignAdd(){
      var data = {};
      data.subject = this.subject;
      data.default = this.default;
      data.body = this.body;
      this.$store.dispatch("mailjs/SignAdd",data);
    },
    Back() {
      this.$router.go(-1);
    },
  },
};
</script>

<style>
</style>