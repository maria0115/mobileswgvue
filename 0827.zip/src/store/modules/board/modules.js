export const dataStore = {
    state: {
        board: {
            path: "notice",
            unid:"",
            parents:[],
            edit:false,
        },
    }
}