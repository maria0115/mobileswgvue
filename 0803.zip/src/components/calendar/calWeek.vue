<template>
  <div>
    <date-header @calMenu="CalMenu"></date-header>
    <Header :calmenu="this.calmenu" @calMenuOff="CalMenuOff"></Header>
    <div class="m_contents09">
      <div class="week_day">
        <div>
          <span>SUN</span>
          <em>23</em>
        </div>
        <div class="to_day">
          <span>MON</span>
          <em>24</em>
        </div>
        <div>
          <span>TUE</span>
          <em>25</em>
        </div>
        <div>
          <span>WED</span>
          <em>26</em>
        </div>
        <div>
          <span>THU</span>
          <em>27</em>
        </div>
        <div>
          <span>FRI</span>
          <em>28</em>
        </div>
        <div>
          <span>SAT</span>
          <em>29</em>
        </div>
      </div>
      <div class="week_cal_con">
        <ul>
          <li>
            <div>
              <span>종일</span>
            </div>
            <div class="week_caltit">
              <div class="sun">
                <!--해당날짜일떄 active 생기게 해주세요-->
                <em></em>
              </div>
              <div class="mon active">
                <em>주간회의</em>
              </div>
              <div class="tue">
                <em></em>
              </div>
              <div class="wed">
                <em></em>
              </div>
              <div class="thu">
                <em>신규채용</em>
              </div>
              <div class="fri">
                <em></em>
              </div>
              <div class="sat">
                <em>창립기념</em>
              </div>
            </div>
          </li>
          <li class="timeline">
            <div class="time"><div>00:00</div></div>
            <div class="time_con">
              <div class="week_caltit">
                <div class="sun">
                  <em></em>
                </div>
                <div class="mon">
                  <em></em>
                </div>
                <div class="tue">
                  <em></em>
                </div>
                <div class="wed">
                  <em></em>
                </div>
                <div class="thu">
                  <em></em>
                </div>
                <div class="fri">
                  <em></em>
                </div>
                <div class="sat">
                  <em></em>
                </div>
              </div>
            </div>
          </li>
          <li class="timeline">
            <div class="time"><div>01:00</div></div>
            <div class="time_con">
              <div class="week_caltit clfix">
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
              </div>
            </div>
          </li>
          <li class="timeline">
            <div class="time"><div>02:00</div></div>
            <div class="time_con">
              <div class="week_caltit">
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
              </div>
            </div>
          </li>
          <li class="timeline">
            <div class="time"><div>03:00</div></div>
            <div class="time_con">
              <div class="week_caltit">
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
              </div>
            </div>
          </li>
          <li class="timeline">
            <div class="time"><div>04:00</div></div>
            <div class="time_con">
              <div class="week_caltit">
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
              </div>
            </div>
          </li>
          <li class="timeline">
            <div class="time"><div>05:00</div></div>
            <div class="time_con">
              <div class="week_caltit">
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
              </div>
            </div>
          </li>
          <li class="timeline">
            <div class="time"><div>06:00</div></div>
            <div class="time_con">
              <div class="week_caltit">
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
              </div>
            </div>
          </li>
          <li class="timeline">
            <div class="time"><div>07:00</div></div>
            <div class="time_con">
              <div class="week_caltit">
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
              </div>
            </div>
          </li>
          <li class="timeline">
            <div class="time"><div>08:00</div></div>
            <div class="time_con">
              <div class="week_caltit">
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
              </div>
            </div>
          </li>
          <li class="timeline">
            <div class="time">
              <div>09:00</div>
            </div>
            <div class="time_con">
              <div class="week_caltit">
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
              </div>
            </div>
          </li>
          <li class="timeline">
            <div class="time"><div>10:00</div></div>
            <div class="time_con">
              <div class="week_caltit">
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
              </div>
            </div>
          </li>
          <li class="timeline">
            <div class="time"><div>11:00</div></div>
            <div class="time_con">
              <div class="week_caltit">
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
              </div>
            </div>
          </li>
          <li class="timeline">
            <div class="time"><div>12:00</div></div>
            <div class="time_con">
              <div class="week_caltit">
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
              </div>
            </div>
          </li>
          <li class="timeline">
            <div class="time"><div>13:00</div></div>
            <div class="time_con">
              <div class="week_caltit">
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
              </div>
            </div>
          </li>
          <li class="timeline">
            <div class="time"><div>14:00</div></div>
            <div class="time_con">
              <div class="week_caltit">
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
              </div>
            </div>
          </li>
          <li class="w_timeline">
            <div class="time"><div>15:00</div></div>
            <div class="time_con">
              <div class="week_caltit">
                <div>
                  <em></em>
                </div>
                <div class="time_day">
                  <a href="./mob_cal_read.html">
                    <em>신규서비스 리뷰 회의</em>
                  </a>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
              </div>
            </div>
          </li>
          <li class="timeline">
            <div class="time"><div>16:00</div></div>
            <div class="time_con">
              <div class="week_caltit">
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
              </div>
            </div>
          </li>
          <li class="timeline">
            <div class="time"><div>17:00</div></div>
            <div class="time_con">
              <div class="week_caltit">
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
              </div>
            </div>
          </li>
          <li class="timeline">
            <div class="time"><div>18:00</div></div>
            <div class="time_con">
              <div class="week_caltit">
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
              </div>
            </div>
          </li>
          <li class="timeline">
            <div class="time"><div>19:00</div></div>
            <div class="time_con">
              <div class="week_caltit">
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
              </div>
            </div>
          </li>
          <li class="timeline">
            <div class="time"><div>20:00</div></div>
            <div class="time_con">
              <div class="week_caltit">
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
              </div>
            </div>
          </li>
          <li class="timeline">
            <div class="time"><div>21:00</div></div>
            <div class="time_con">
              <div class="week_caltit">
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
              </div>
            </div>
          </li>
          <li class="timeline">
            <div class="time"><div>22:00</div></div>
            <div class="time_con">
              <div class="week_caltit">
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
                <div>
                  <em></em>
                </div>
              </div>
            </div>
          </li>
          <li class="timeline">
            <div class="time">
              <div>23:00</div>
              <div>24:00</div>
            </div>
            <div class="time_con"></div>
          </li>
        </ul>
        <span class="now_line"></span>
      </div>
      <span class="today_btn">Today</span>
    </div>
    <span class="w_cal_btn"><a href="./mob_cal_write.html"></a></span>
  </div>
</template>

<script>
import Header from "./header.vue";
import DateHeader from "./datepicker.vue";

export default {
  components: {
    Header,
    DateHeader,
  },
  data() {
    return {
      calmenu: false,
    };
  },
  methods: {
    CalMenu() {
      this.calmenu = true;
    },
    CalMenuOff() {
      this.calmenu = false;
    },
    getWeekNo(v_date_str) {
      var date = new Date();
      if (v_date_str) {
        date = new Date(v_date_str);
      }
      return Math.ceil(date.getDate() / 7);
    },
  },
};
</script>

<style>
</style>