<template>
  <div>
    <div class="cal_header">
      <h2 class="month_date">
        <em class="c_prev" @click="calendarData(-1)"></em>
        <!-- <month-picker-input></month-picker-input> -->
        <vue-monthly-picker
          v-model="selectedMonth"
          @selected="DateChange($event)"
        >
        </vue-monthly-picker>
        <em class="c_next" @click="calendarData(1)"></em>
      </h2>
      <span class="sub_ham" @click="calMenu"></span>
    </div>
    <Header :calmenu="this.calmenu" @calMenuOff="CalMenuOff"></Header>
    <div class="m_contents08">
      <table>
        <thead>
          <tr>
            <th class="holiday"><em>SUN</em></th>
            <th><em>MON</em></th>
            <th><em>TUE</em></th>
            <th><em>WED</em></th>
            <th><em>THU</em></th>
            <th><em>FRI</em></th>
            <th class="sat"><em>SAT</em></th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(date, idx) in dates" :key="idx">
            <td v-for="(day, secondIdx) in date" :key="secondIdx">
              <a href="#">
                <div
                  :class="{
                    last_month: idx === 0 && day >= lastMonthStart,
                    next_month:
                      dates.length - 1 === idx && nextMonthStart > day,
                    t_day:
                      day === today &&
                      month === currentMonth &&
                      year === currentYear &&
                      !(dates.length - 1 === idx && nextMonthStart > day),
                    sat: days.length - 1 === secondIdx,
                    sun: secondIdx === 0,
                  }"
                >
                  <em>{{ day }}</em>
                </div>
              </a>
            </td>
          </tr>
        </tbody>
        <!-- <td>
              <a href="#">
                <div class="holiday"><em>5</em></div>
                <span class="hol_event">어린이날</span>
              </a>
            </td>
<td>
              <a href="./mob_cal_list.html">
                <div class="t_day"><em>24</em></div>
                <span class="all_day">주간회의</span>
                <span class="time_day">신규서비스</span>
              </a>
            </td>
			<td>
              <a href="#">
                <div><em>27</em></div>
                <span class="all_day"> 신규채용 </span>
              </a>
            </td>
			
			<a href="#">
                <div class="sun last_month"><em>25</em></div>
              </a>
			  href="#">
                <div class="sat next_month"><em>5</em></div>
              </a> -->
      </table>
      <span class="today_btn" @click="Today">Today</span>
    </div>
    <span class="w_cal_btn"><a href="./mob_cal_write.html"></a></span>
  </div>
</template>

<script>
import Header from "./header.vue";
import { MonthPickerInput } from "vue-month-picker";
import VueMonthlyPicker from "vue-monthly-picker";
import axios from "axios";
export default {
  components: {
    Header,
    MonthPickerInput,
    VueMonthlyPicker,
  },
  created() {
    this.Init();
  },
  data() {
    return {
      calmenu: false,
      date: {
        from: null,
        to: null,
        month: null,
        year: null,
      },
      days: [
        "일요일",
        "월요일",
        "화요일",
        "수요일",
        "목요일",
        "금요일",
        "토요일",
      ],
      selectedMonth: null,
      dates: [],
      currentYear: 0,
      currentMonth: 0,
      year: 0,
      month: 0,
      lastMonthStart: 20,
      nextMonthStart: 0,
      today: 0,
    };
  },
  methods: {
    calMenu() {
      this.calmenu = true;
    },
    CalMenuOff() {
      this.calmenu = false;
    },
    showDate(date) {
      this.date = date;
    },
    calendarData(arg) {
      var moment = require("moment");
      if (arg < 0) {
        this.month -= 1;
      } else if (arg === 1) {
        this.month += 1;
      }
      if (this.month === 0) {
        this.year -= 1;
        this.month = 12;
      } else if (this.month > 12) {
        this.year += 1;
        this.month = 1;
      }
      this.selectedMonth = moment(`${this.year}/${this.month}`);
      const [monthFirstDay, monthLastDate, lastMonthLastDate] =
        this.getFirstDayLastDate(this.year, this.month);
      this.dates = this.getMonthOfDays(
        monthFirstDay,
        monthLastDate,
        lastMonthLastDate
      );
    },
    getFirstDayLastDate(year, month) {
      const firstDay = new Date(year, month - 1, 1).getDay();
      const lastDate = new Date(year, month, 0).getDate();
      let lastYear = year;
      let lastMonth = month - 1;
      if (month === 1) {
        lastMonth = 12;
        lastYear -= 1;
      }
      const prevLastDate = new Date(lastYear, lastMonth, 0).getDate();
      return [firstDay, lastDate, prevLastDate];
    },
    getMonthOfDays(monthFirstDay, monthLastDate, prevMonthLastDate) {
      let day = 1;
      let prevDay = prevMonthLastDate - monthFirstDay + 1;
      const dates = [];
      let weekOfDays = [];
      while (day <= monthLastDate) {
        if (day === 1) {
          for (let j = 0; j < monthFirstDay; j += 1) {
            if (j === 0) this.lastMonthStart = prevDay;
            weekOfDays.push(prevDay);
            prevDay += 1;
          }
        }
        weekOfDays.push(day);
        if (weekOfDays.length === 7) {
          dates.push(weekOfDays);
          weekOfDays = [];
        }
        day += 1;
      }
      const len = weekOfDays.length;
      if (len > 0 && len < 7) {
        for (let k = 1; k <= 7 - len; k += 1) {
          weekOfDays.push(k);
        }
      }
      if (weekOfDays.length > 0) dates.push(weekOfDays);
      this.nextMonthStart = weekOfDays[0];
      return dates;
    },
    DateChange(e) {
      if (e) {
        this.year = parseInt(e["_i"].split("/")[0]);
        this.month = parseInt(e["_i"].split("/")[1]);
        this.calendarData();
      }
    },
    Today() {
      this.Init();
    },
    Init() {
      const date = new Date();
      this.currentYear = date.getFullYear();
      this.currentMonth = date.getMonth() + 1;
      this.year = this.currentYear;
      this.month = this.currentMonth;

      this.today = date.getDate();
      this.calendarData();
      this.Rest();
    },
    Rest() {
      console.log("요기");
      var url =
        "http://apis.data.go.kr/B090041/openapi/service/SpcdeInfoService/getRestDeInfo";
      var queryParams =
        "?" +
        encodeURIComponent("ServiceKey") +
        "=" +
        "g096ZBtifZ1PgsemrJxwCNIhW4r4gv2ohQvgSk5udZpqFH54or/v9YqWc8ruDvoddJ63HUZSisAnEhKAsAFSEw=="; /* Service Key*/
      queryParams +=
        "&" +
        encodeURIComponent("solYear") +
        "=" +
        encodeURIComponent(this.year); /* */
      queryParams +=
        "&" +
        encodeURIComponent("solMonth") +
        "=" +
        encodeURIComponent(this.fill(2,this.month)); /* */

      console.log(url + queryParams);

      return axios({
        method: "get",
        url: url + queryParams,
      });
    },
    fill(width,str) {
      let n = String(str); //문자열 변환
      return n.length >= width
        ? n
        : new Array(width - n.length + 1).join("0") + n; //남는 길이만큼 0으로 채움
    },
  },
};
</script>

<style>
</style>