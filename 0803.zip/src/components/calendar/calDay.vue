<template>
  <div>
    <date-header @calMenu="CalMenu" ></date-header>
<Header @calMenuOff="CalMenuOff" :calmenu="this.calmenu"></Header>
    <div class="m_contents09">
      <div class="day_cal_con">
        <ul>
          <li>
            <div>
              <span>MON</span>
              <b>24</b>
            </div>
            <div><p>주간회의</p></div>
          </li>
          <li class="timeline">
            <div><div>00:00</div></div>
            <div class="time_con">
              <p>
                <a href="#">
                  <span class="time">15:00 ~ 16:00</span>
                  <span class="con">신규서비스 리뷰 회의</span>.
                </a>
              </p>
              <p>
                <a href="">
                  <span class="time">15:00 ~ 16:00</span>
                  <span class="con">신규서비스 리뷰 회의</span>.
                </a>
              </p>
            </div>
          </li>
          <li class="timeline">
            <div><div>01:00</div></div>
            <div class="time_con">
              <p>
                <a href="#">
                  <span class="time">15:00 ~ 16:00</span>
                  <span class="con">신규서비스 리뷰 회의</span>.
                </a>
              </p>
            </div>
          </li>
          <li class="timeline">
            <div><div>02:00</div></div>
            <div class="time_con">
              <p>
                <a href="#">
                  <span class="time">15:00 ~ 16:00</span>
                  <span class="con">신규서비스 리뷰 회의</span>.
                </a>
              </p>
            </div>
          </li>
          <li class="timeline">
            <div><div>03:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>04:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>05:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>06:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>07:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>08:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>09:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>10:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>11:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>12:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>13:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>14:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>15:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>16:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>17:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>18:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>19:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>20:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>21:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>22:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div>
              <div>23:00</div>
              <div>24:00</div>
            </div>
            <div class="time_con"></div>
          </li>
        </ul>
        <span class="now_line"></span>
      </div>
      <span class="today_btn">Today</span>
    </div>
    <span class="w_cal_btn"><a href="./mob_cal_write.html"></a></span>
  </div>
</template>

<script>
import Header from "./header.vue";
import DateHeader from "./datepicker.vue";


export default {
  components: {
    Header,
    DateHeader,
  },
  data() {
    return {
      calmenu:false,
    };
  },
  methods:{
      CalMenu(){
          this.calmenu = true;

      },
      CalMenuOff(){
          this.calmenu = false;
      },
  },
};
</script>

<style>
</style>