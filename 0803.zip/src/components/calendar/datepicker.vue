<template>
  <div class="cal_header">
    <h2 class="week_date">
      <em class="c_prev"></em>
      <div>
        <input
          type="text"
          value="2021.05.24"
          id="datepicker_input"
          class="datepicker-here"
          data-language="en"
        />
      </div>
      <em class="c_next"></em>
    </h2>
    <span class="sub_ham" @click="$emit('calMenu')"></span>
  </div>
</template>

<script>
export default {
  methods: {
    CalMenu() {},
  },
  
};
</script>

<style>
</style>