<template>
  <div>
      <div class="cal_header">
        <h2 class="today_date">
            2021.05.25 (화)
        </h2>
        <em>
            <a href="./mob_calendar.html"><img src="../../mobile/img/m_edit_icon01.png" alt=""></a>
        </em>
    </div>
    <div class="m_contents08">
        <ul class="cal_view">
            <li>
                <a href="#">
                    <dl>
                        <dt>종일</dt>
                        <dd>주간회의</dd>
                    </dl>
                </a>
            </li>
            <li>
                <a href="./mob_cal_read.html">
                    <dl>
                        <dt>15:00~16:00</dt>
                        <dd>신규서비스 리뷰 회의</dd>
                    </dl>
                </a>
            </li>
        </ul>
        <div class="no_schedule">
            <div>
                <span></span>
                <p>등록된 일정이 없습니다.<br>일정을 등록하세요</p>
            </div>
        </div>
    </div>
    <span class="w_cal_btn"><a href="./mob_wmail.html"></a></span>
    <ul class="btm_btn clfix">
        <li class="home"><a href="./mob_main.html"></a></li>
        <li class="back"><a href=""></a></li>
        <li class="go"><a href=""></a></li>
        <li class="refresh"><a href=""></a></li>
        <li class="link"><a href=""></a></li>
        <li class="btm_more"><a href=""></a></li>
    </ul>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>