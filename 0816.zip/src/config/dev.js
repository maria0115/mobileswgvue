const config = require('./config.json');

module.exports = config;