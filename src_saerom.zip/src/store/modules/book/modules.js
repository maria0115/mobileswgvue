export const dataStore = {
    state: {
        unid:"",
        nowroom:{},
        edit:false,
    }
}