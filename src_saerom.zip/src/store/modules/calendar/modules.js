export const dataStore = {
    state: {
        edit:false,
        schedule:{
            detail:{
                unid:"",
                where:"month"
            },
        },
        schedulelist:{
            data:[],
            date:{}
        },
    }
}