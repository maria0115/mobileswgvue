<template>
  <span class="w_mail_btn"><router-link to="/board_more/write"></router-link></span>
</template>

<script>
export default {
  methods: {
    
  },
  props: {
    path: String,
  },

}
</script>

<style>

</style>