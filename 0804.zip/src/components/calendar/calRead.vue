<template>
  <div>
      <div class="rdcal_header">
        <em><a href="./mob_cal_list.html"><img src="../../mobile/img/wmail_back.png" alt=""></a>일정</em>
        <div class="rdcal_icons">
            <span class="rdcal_edit"><a href="./mob_cal_edit.html">편집</a></span>
            <span class="rdcal_edit_del">삭제</span>
        </div>
    </div>
    <div class="m_contents08">
        <div class="con_body_top">
            <span>신규서비스 리뷰 회의</span>
            <em><b class="cate">회의</b> / <b class="open">공개</b></em>
        </div>
        <ul class="rd_list">
            <li>
                <span>일자</span>
                <div>2021-05-24(월)</div>
            </li>
            <li>
                <span>시간</span>
                <div>15:00 ~ 16:00</div>
            </li>
            <li>
                <span>위치</span>
                <div>영업팀 앞 회의실</div>
            </li>
            <li>
                <span>첨부파일</span>
                <ul class="file_list">
                    <li>IMG0534.JPG</li>
                    <li>IMG0534.JPG</li>
                </ul>
            </li>
        </ul>
        <div class="cal_info">
            금일 협업사업부 신규서비스 리뷰 회의가<br>영업팀 앞 회의실에서 있을 에정이니다.  
        </div>
    </div>
    <ul class="btm_btn clfix">
        <li class="home"><a href="./mob_main.html"></a></li>
        <li class="back"><a href=""></a></li>
        <li class="go"><a href=""></a></li>
        <li class="refresh"><a href=""></a></li>
        <li class="link"><a href=""></a></li>
        <li class="btm_more"><a href=""></a></li>
    </ul>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>