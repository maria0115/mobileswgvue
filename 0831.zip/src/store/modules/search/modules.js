export const dataStore = {
    state: {
    }
}