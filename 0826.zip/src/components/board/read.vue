<template>
  <div>
    <div class="wnoti_header">
      <h2>
        <a @click="Back()"
          ><img src="../../mobile/img/wmail_back.png" alt="" /></a
        >{{ GetStoreBoard.path }}
      </h2>
      <div>
        <span class="edit">수정</span>
        <span class="del">삭제</span>
      </div>
    </div>
    <div class="m_contents04">
      <div class="nt_top">
        <h3 class="noti_tit">{{ GetStoreBoard.detail.subject }}</h3>
        <div class="clfix">
          <span class="per_img">
            <em class="no_img" :style="randomColor()"><b>{{ GetStoreBoard.detail.author.split("")[0] }}</b></em>
          </span>
          <dl>
            <dt>
              {{ GetStoreBoard.detail.author }}
              {{ GetStoreBoard.detail.authorGrade }} /
              {{ GetStoreBoard.detail.authorDept }}
            </dt>
            <dd>
              {{ transTime(GetStoreBoard.detail.created) }}
              <span
                >조회 : <em>{{ GetStoreBoard.detail.read_cnt }}</em></span
              >
            </dd>
          </dl>
          <em class="re_more"></em>
        </div>
      </div>
      <div class="posting">
        <p>
          <span>게시기간</span
          ><em v-if="GetStoreBoard.detail.isEternity">영구</em
          ><em v-else
            >{{ btransTime(GetStoreBoard.detail.startDate) }} ~
            {{ btransTime(GetStoreBoard.detail.endDate) }}</em
          >
        </p>
      </div>
      <div
        class="add_file nt_file clfix"
        v-if="GetStoreBoard.detail.attach.length > 0"
      >
        <strong>첨부파일</strong>
        <ul>
          <li
            @click="attachClick(value.path)"
            class="active"
            v-for="(value, index) in GetStoreBoard.detail.attach"
            :key="index"
          >
            <span><img src="../../mobile/img/test_img01.png" alt="" /></span>
            <div>
              <p>{{ value.name }}</p>
              <em>(32.52KB)</em>
            </div>
          </li>
        </ul>
      </div>
      <div class="noti_con" v-html="GetStoreBoard.detail.body"></div>
      <div class="like_btn">
        <span
          ><em>{{ GetStoreBoard.detail.like_cnt }}</em> LIKE <b></b
        ></span>
      </div>
      <div class="comment">
        <span>댓글 <em>9</em></span>
        <div class="com_input">
          <div class="f_com">
            <textarea placeholder="댓글을 작성해 주세요."></textarea>
            <span class="en_btn">등록</span>
          </div>
        </div>
        <div :class="[{c_com:value.parent_unid===''},{cc_com:value.parent_unid!==''}]" v-for="(value,index) in GetStoreBoard.detail.reply" :key="index">
          <span class="per_img">
            <em class="no_img" :style="randomColor()"><b>{{value.author.split("")[0]}}</b></em>
          </span>
          <dl>
            <dt>{{value.author}} {{value.authorGrade}} / {{value.authorDept}}</dt>
            <dd>{{transTime(value.created)}}</dd>
          </dl>
          <div class="com_icons">
            <span class="com_ic"></span>
            <span class="edit_ic" v-if="isMe(value)"></span>
            <span class="del_ic" v-if="isMe(value)"></span>
          </div>
          <p>{{value.body}}</p>
          <div class="ccc_com">
            <div class="s_com">
              <textarea placeholder="댓글을 작성해 주세요."></textarea>
              <span class="en_btn">등록</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState, mapGetters } from "vuex";
export default {
  computed: {
    ...mapGetters("boardjs", ["GetStoreBoard"]),
    ...mapGetters("mainjs", ["GetMyInfo"]),
  },
  methods: {
    // 기본이미지 랜덤 색
    randomColor() {
      const color = ["#bcbbdd", "#bbcbdd", "#bbddd7", "#d0d0d0"];
      return `background: ${color[Math.floor(Math.random() * 4)]}`;
    },
    isMe(value) {
      var my = this.GetMyInfo.info;
      if(my.name == value.author && my.sabun === value.sabun){
        return true;
      }
      return false;

    },
    getReadableByte(count, decimal = 2, level = 0) {
      let unitList = ["Bytes", "KB", "MB", "GB", "TB", "PT"];

      if (count >= 1024.0 && level + 1 < unitList.length) {
        return this.getReadableByte(count / 1024, decimal, ++level);
      }
      return `${decimal ? count.toFixed(decimal) : Math.round(count)}${
        unitList[level]
      }`;
    },
    Back() {
      this.$router.replace(`${this.GetStoreBoard.path}`);
    },
    // utc 시간 to local 시간
    transTime(time) {
      var moment = require("moment");
      var localTime = moment.utc(time).toDate();
      localTime = moment(localTime).format("YYYY.MM.DD HH:mm");
      return localTime;
    },
    attachClick(url) {
      window.open(url);
    },
    btransTime(time) {
      var moment = require("moment");
      var localTime = moment.utc(time).toDate();
      localTime = moment(localTime).format("YY.MM.DD");
      return localTime;
    },
    // utc 시간 to local 시간
    transTime(time) {
      var moment = require("moment");
      var localTime = moment.utc(time).toDate();
      localTime = moment(localTime).format("YYYY.MM.DD HH:mm");
      return localTime;
    },
  },
};
</script>

<style>
</style>