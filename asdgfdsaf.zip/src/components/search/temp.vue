<template>
  <div>
      <div id="tab04"></div>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>