<template>
  <div>
    <date-header
    @ChangeDate="changeDate"
      @cNext="calendarData(1)"
      @cPrev="calendarData(-1)"
      :date="fulldate"
      @calMenu="CalMenu"
    ></date-header>
    <Header @calMenuOff="CalMenuOff" :calmenu="this.calmenu"></Header>
    <div class="m_contents09">
      <div class="day_cal_con">
        <ul>
          <li>
            <div>
              <span>{{this.daysSort[this.theDayOfWeek]}}</span>
              <b>{{this.today}}</b>
            </div>
            <div><p>주간회의</p></div>
          </li>
          <li class="timeline">
            <div><div>00:00</div></div>
            <div class="time_con">
              <p>
                <a href="#">
                  <span class="time">15:00 ~ 16:00</span>
                  <span class="con">신규서비스 리뷰 회의</span>.
                </a>
              </p>
              <p>
                <a href="">
                  <span class="time">15:00 ~ 16:00</span>
                  <span class="con">신규서비스 리뷰 회의</span>.
                </a>
              </p>
            </div>
          </li>
          <li class="timeline">
            <div><div>01:00</div></div>
            <div class="time_con">
              <p>
                <a href="#">
                  <span class="time">15:00 ~ 16:00</span>
                  <span class="con">신규서비스 리뷰 회의</span>.
                </a>
              </p>
            </div>
          </li>
          <li class="timeline">
            <div><div>02:00</div></div>
            <div class="time_con">
              <p>
                <a href="#">
                  <span class="time">15:00 ~ 16:00</span>
                  <span class="con">신규서비스 리뷰 회의</span>.
                </a>
              </p>
            </div>
          </li>
          <li class="timeline">
            <div><div>03:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>04:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>05:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>06:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>07:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>08:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>09:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>10:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>11:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>12:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>13:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>14:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>15:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>16:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>17:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>18:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>19:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>20:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>21:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div><div>22:00</div></div>
            <div class="time_con"></div>
          </li>
          <li class="timeline">
            <div>
              <div>23:00</div>
              <div>24:00</div>
            </div>
            <div class="time_con"></div>
          </li>
        </ul>
        <span class="now_line"></span>
      </div>
      <span class="today_btn" @click="Today">Today</span>
    </div>
    <span class="w_cal_btn"><a href="./mob_cal_write.html"></a></span>
  </div>
</template>

<script>
import Header from "./header.vue";
import DateHeader from "./datepicker.vue";

export default {
  created(){
    this.Init();
  },
  components: {
    Header,
    DateHeader,
  },
  data() {
    return {
      calmenu: false,
      fulldate:"",
      currentYear: 0,
      currentMonth: 0,
      currentDay: 0,
      year: 0,
      month: 0,
      today: 0,
      theDayOfWeek: 0,
      daysSort: ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"],
    };
  },
  methods: {
    Today() {
      this.Init();
    },
    CalMenu() {
      this.calmenu = true;
    },
    CalMenuOff() {
      this.calmenu = false;
    },
    Init() {
      var currentDay = new Date();
      this.currentYear = currentDay.getFullYear();
      this.currentMonth = currentDay.getMonth() + 1;
      this.year = this.currentYear;
      this.month = this.currentMonth;
      this.today = currentDay.getDate();
      this.currentDay = this.today;
      this.fulldate = `${this.year}.${this.fill(2, this.month)}.${this.fill(
        2,
        this.today
      )}`;

    },
    calendarData(arg) {
      if (arg < 0) {
        this.month -= 1;
      } else if (arg === 1) {
        this.month += 1;
      }
      if (this.month === 0) {
        this.year -= 1;
        this.month = 12;
      } else if (this.month > 12) {
        this.year += 1;
        this.month = 1;
      }
      this.fulldate = `${this.year}.${this.fill(2, this.month)}.${this.fill(
        2,
        this.today
      )}`;
      var currentDay = new Date(this.fulldate);
      this.theDayOfWeek = currentDay.getDay();
      
    },
    changeDate(date) {
      this.year = parseInt(date.split(".")[0]);
      this.month = parseInt(date.split(".")[1]);
      this.today = parseInt(date.split(".")[2]);
      this.calendarData();
    },
    fill(width, str) {
      let n = String(str);
      return n.length >= width
        ? n
        : new Array(width - n.length + 1).join("0") + n;
    },
  },
};
</script>

<style>
</style>