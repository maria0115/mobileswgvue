<template>
  <div>
    <date-header
      @ChangeDate="changeDate"
      @calMenu="CalMenu"
      :date="fulldate"
      @cNext="calendarData(1)"
      @cPrev="calendarData(-1)"
      @change="DateChange($event)"
    ></date-header>
    <Header :calmenu="this.calmenu" @calMenuOff="CalMenuOff"></Header>
    <div class="m_contents08">
      <table>
        <thead>
          <tr>
            <th class="holiday"><em>SUN</em></th>
            <th><em>MON</em></th>
            <th><em>TUE</em></th>
            <th><em>WED</em></th>
            <th><em>THU</em></th>
            <th><em>FRI</em></th>
            <th class="sat"><em>SAT</em></th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(date, idx) in dates" :key="idx">
            <td v-for="(day, secondIdx) in date" :key="secondIdx">
              <a href="#">
                <div
                  :class="{
                    last_month: idx === 0 && day >= lastMonthStart,
                    next_month:
                      dates.length - 1 === idx && nextMonthStart > day,
                    t_day:
                      day === today &&
                      month === month &&
                      year === year &&
                      !(dates.length - 1 === idx && nextMonthStart > day) &&
                      !(idx === 0 && day >= lastMonthStart),
                    sat: days.length - 1 === secondIdx,
                    sun: secondIdx === 0,
                    holiday:
                      isHoliday(day).boo &&
                      !(dates.length - 1 === idx && nextMonthStart > day) &&
                      !(idx === 0 && day >= lastMonthStart),
                  }"
                >
                  <em>{{ day }}</em>
                </div>
                <span
                  v-if="
                    isHoliday(day).boo &&
                    !(dates.length - 1 === idx && nextMonthStart > day) &&
                    !(idx === 0 && day >= lastMonthStart)
                  "
                  class="hol_event"
                  >{{ isHoliday(day).name }}</span
                >
              </a>
            </td>
          </tr>
        </tbody>
        <!-- <a href="./mob_cal_list.html">
                <div class="t_day"><em>24</em></div>
                <span class="all_day">주간회의</span>
                <span class="time_day">신규서비스</span>
              </a>
            </td>
			<td>
              <a href="#">
                <div><em>27</em></div>
                <span class="all_day"> 신규채용 </span>
              </a>
            </td> -->
      </table>
      <span class="today_btn" @click="Today">Today</span>
    </div>
    <span class="w_cal_btn"><a href="./mob_cal_write.html"></a></span>
  </div>
</template>

<script>
import Header from "./header.vue";
import { MonthPickerInput } from "vue-month-picker";
import VueMonthlyPicker from "vue-monthly-picker";
import { mapState, mapGetters } from "vuex";
import DateHeader from "./datepicker.vue";
export default {
  components: {
    Header,
    MonthPickerInput,
    VueMonthlyPicker,
    DateHeader,
  },
  created() {
    this.Init();
  },
  data() {
    return {
      calmenu: false,
      days: [
        "일요일",
        "월요일",
        "화요일",
        "수요일",
        "목요일",
        "금요일",
        "토요일",
      ],
      selectedMonth: null,
      dates: [],
      currentYear: 0,
      currentMonth: 0,
      year: 0,
      month: 0,
      premonth:0,
      lastMonthStart: 20,
      nextMonthStart: 0,
      today: 0,
      fulldate: "",
    };
  },
  computed: {
    ...mapGetters(["GetSchedule"]),
  },
  methods: {
    CalMenu() {
      this.calmenu = true;
    },
    CalMenuOff() {
      this.calmenu = false;
    },
    isHoliday(day) {
      var data = {};
      const holiday = this.GetSchedule.holiday;

      if (Object.keys(holiday).length > 0 && Array.isArray(holiday)) {
        // 여러개일때
        for (var i = 0; i < holiday.length; i++) {
          if (parseInt(String(holiday[i].locdate).substring(6)) == day) {
            data.boo = true;
            data.name = holiday[i].dateName;
            return data;
          }
        }
        data.boo = false;
        return data;
      } else if (Object.keys(holiday).length > 0) {
        // 하나일때
        if (parseInt(String(holiday.locdate).substring(6)) == day) {
          data.boo = true;
          data.name = holiday.dateName;
          return data;
        }
        data.boo = false;
        return data;
      } else {
        data.boo = false;
        return data;
      }
    },
    calMenu() {
      this.calmenu = true;
    },
    CalMenuOff() {
      this.calmenu = false;
    },
    showDate(date) {
      this.date = date;
    },
    async calendarData(arg) {
      var moment = require("moment");
      if (arg < 0) {
        this.month -= 1;
      } else if (arg === 1) {
        this.month += 1;
      }
      if (this.month === 0) {
        this.year -= 1;
        this.month = 12;
      } else if (this.month > 12) {
        this.year += 1;
        this.month = 1;
      }
      this.fulldate = `${this.year}.${this.fill(2, this.month)}.${this.fill(
        2,
        this.today
      )}`;
      this.selectedMonth = moment(`${this.year}/${this.month}`, "yyyyMM");
      await this.Rest();
      this.premonth = this.month;
      const [monthFirstDay, monthLastDate, lastMonthLastDate] =
        this.getFirstDayLastDate(this.year, this.month);
      this.dates = this.getMonthOfDays(
        monthFirstDay,
        monthLastDate,
        lastMonthLastDate
      );
    },
    getFirstDayLastDate(year, month) {
      const firstDay = new Date(year, month - 1, 1).getDay();
      const lastDate = new Date(year, month, 0).getDate();
      let lastYear = year;
      let lastMonth = month - 1;
      if (month === 1) {
        lastMonth = 12;
        lastYear -= 1;
      }
      const prevLastDate = new Date(lastYear, lastMonth, 0).getDate();
      return [firstDay, lastDate, prevLastDate];
    },
    getMonthOfDays(monthFirstDay, monthLastDate, prevMonthLastDate) {
      let day = 1;
      let prevDay = prevMonthLastDate - monthFirstDay + 1;
      const dates = [];
      let weekOfDays = [];
      while (day <= monthLastDate) {
        if (day === 1) {
          for (let j = 0; j < monthFirstDay; j += 1) {
            if (j === 0) this.lastMonthStart = prevDay;
            weekOfDays.push(prevDay);
            prevDay += 1;
          }
        }
        weekOfDays.push(day);
        if (weekOfDays.length === 7) {
          dates.push(weekOfDays);
          weekOfDays = [];
        }
        day += 1;
      }
      const len = weekOfDays.length;
      if (len > 0 && len < 7) {
        for (let k = 1; k <= 7 - len; k += 1) {
          weekOfDays.push(k);
        }
      }
      if (weekOfDays.length > 0) dates.push(weekOfDays);
      this.nextMonthStart = weekOfDays[0];
      return dates;
    },
    DateChange(e) {
      if (e) {
        this.year = parseInt(e["_i"].split("/")[0]);
        this.month = parseInt(e["_i"].split("/")[1]);
        this.calendarData();
      }
    },
    Today() {
      this.Init();
    },
    Init() {
      const date = new Date();
      this.currentYear = date.getFullYear();
      this.currentMonth = date.getMonth() + 1;
      this.year = this.currentYear;
      this.month = this.currentMonth;

      this.today = date.getDate();
      this.fulldate = `${this.year}.${this.fill(2, this.month)}.${this.fill(
        2,
        this.today
      )}`;
      this.calendarData();
    },
    Rest() {
      if(this.premonth!==this.month){
        var data = {};
        data.year = this.year;
        data.month = this.fill(2, this.month);
        data.menu = "holiday";
  
        this.$store.dispatch("Holiday", data);

      }
      return;
    },
    fill(width, str) {
      let n = String(str);
      return n.length >= width
        ? n
        : new Array(width - n.length + 1).join("0") + n;
    },
    changeDate(date) {
      this.year = parseInt(date.split(".")[0]);
      this.month = parseInt(date.split(".")[1]);
      this.today = parseInt(date.split(".")[2]);
      this.calendarData();
    },
  },
};
</script>

<style>
</style>