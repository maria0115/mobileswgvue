<template>
  <div class="ac_btns">
        <span class="more_plus"></span>
        <ul>
            <li class="top"><a>맨 위로</a></li>
            <li v-for="(value,name) in menu" :key="name" @click="BtnClick(name)"><a>{{value}}</a></li>
        </ul>
    </div>
</template>

<script>
export default {
    props: {
    menu: Object,
  },
  methods: {
    BtnClick(value){
      this.$emit("BtnClick",value);
    },
  }

}
</script>

<style>

</style>