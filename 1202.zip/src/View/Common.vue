<template>
  <div style="height:100%">
    <router-view ></router-view>
    <Footer></Footer>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>