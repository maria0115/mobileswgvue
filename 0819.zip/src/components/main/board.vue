<template>
  <div id="board_tab">
    <div class="board01">
      <strong>공지사항</strong>
      <ul>
        <li class="new"><a href="">메신저 로그인 화면 개선안</a></li>
        <li class="new">
          <a href="">BI와 ERP데이터 정합성 모니터링 리포트</a>
        </li>
        <li><a href="">[결제참조]회계전표(매입/경비-기타)</a></li>
        <li><a href="">[경영기획팀]경영기획실 2월 1주차 팀장회의 자료</a></li>
      </ul>
      <span class="m_more"><a href=""></a></span>
    </div>
    <div class="board02">
      <strong>업무 게시판</strong>
      <ul>
        <li class="new"><a href="">메신저 로그인 화면 개선안</a></li>
        <li class="new">
          <a href="">BI와 ERP데이터 정합성 모니터링 리포트</a>
        </li>
        <li><a href="">[결제참조]회계전표(매입/경비-기타)</a></li>
        <li><a href="">[경영기획팀]경영기획실 2월 1주차 팀장회의 자료</a></li>
      </ul>
      <span class="m_more"><a href=""></a></span>
    </div>
    <div class="board03">
      <strong>경조사</strong>
      <ul>
        <li>
          <a href=""><em class="cc01">[부고]</em>SI팀 길철수 차장 부친상</a>
        </li>
        <li>
          <a href=""><em class="cc02">[결혼]</em>영업관리팀 한애리 대리</a>
        </li>
        <li>
          <a href=""><em class="cc03">[출산]</em>기획팀 이혜진 과장 득남</a>
        </li>
        <li>
          <a href=""><em class="cc01">[부고]</em>마케팅팀 박지후 과장 조모상</a>
        </li>
        <li>
          <a href=""><em class="cc04">[생일]</em>영업관리팀 장수진 사원</a>
        </li>
      </ul>
      <span class="m_more"><a href=""></a></span>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>