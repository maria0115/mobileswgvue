export const dataStore = {
    state: {
        header:{},
    }
}