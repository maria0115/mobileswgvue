
export default {
    SetHeader(state,data) {
        // state.store.header.prevmenu = state.store.header.menu;
        state.store.header.menu = data;

    },

}