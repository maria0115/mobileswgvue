<template>
  <ul v-if="attach" :class="className">
    <li
      v-for="(value, index) in attaInfo"
      :key="index"
      class="active"
      @click="openDownload(value)"
    >
      <span
        ><img :src="`../../mobile/img/icon_${fileImg(value.name)}.png`" alt=""
      /></span>
      <div>
        <!-- <a :href="value.url" download> -->
        <p>{{ value.name }}</p>
        <em v-if="value.size">({{ value.size }})</em>
        <!-- </a> -->
      </div>
    </li>
  </ul>
  <div v-else></div>
</template>

<script>
// 여긴 뷰어
export default {
  props: ["attaInfo", "attach", "className", "unid"],
  methods: {
    openDownload(value) {
      // url = window.location.origin + url;
      // location.href = "https://gwmobile.krb.co.kr"+url
      value.unid = this.unid;
      // return;
      var data = {};
      data.fileType = "URL";
      var filepath = value.url || value.openurl;
      if (!this.attach) {
        filepath = this.Config().originPage + filepath+"&fullscroll=1";
      }
      data.filePath = filepath;
      data.fid = this.generateRandomCode(10);
      data.kind = "synap";
      // var info = JSON.parse(
      //   localStorage.getItem(`${this.Config().packageName}deviceInformation`)
      // );
      data.accessCookieData = btoa(
        `{"LtpaToken":"${this.getToKen()}"}`
      );
      this.$store.dispatch("editorJsonPost", data).then((res) => {
        if (res.key) {
          // var goto = `${window.location.origin}/mobile_index/viewer`;
          var goto = `http://gwmobile.krb.co.kr/mobile_index/viewer`;
          var setToken = this.replaceAll(this.getToKen(), "+", "$SIS$");
          if (this.isApp()) {
            location.href = `m60call://browser?urladdress=${goto}?url=${encodeURIComponent(
              res.viewUrlPath
            )}&token=${encodeURIComponent(setToken)}`;
          } else {
            location.href = `${goto}?url=${encodeURIComponent(
              res.viewUrlPath
            )}&token=${encodeURIComponent(setToken)}`;
          }
        }
      });
    },
  },
};
</script>

<style>
</style>