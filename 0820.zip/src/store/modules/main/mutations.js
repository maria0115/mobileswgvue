
export default {
    // info data
    MyInfo(state, { res }) {
        // state.myinfo={};
        state.store.myinfo = res;
    },

}