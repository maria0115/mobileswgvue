<template>
  <span class="w_mail_btn" @click="Path()"><router-link to="/board/write"></router-link></span>
</template>

<script>
export default {
  methods: {
    Path(){
      this.$store.commit("BoardWritePath",this.path);
    }
  },
  props: {
    path: String,
  },

}
</script>

<style>

</style>