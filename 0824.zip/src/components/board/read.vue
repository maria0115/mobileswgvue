<template>
  <div>
    <div class="wnoti_header">
      <h2>
        <a @click="Back()"
          ><img src="../../mobile/img/wmail_back.png" alt="" /></a
        >자유게시판
      </h2>
      <div>
        <span class="edit">수정</span>
        <span class="del">삭제</span>
      </div>
    </div>
    <div class="m_contents04">
      <div class="nt_top">
        <h3 class="noti_tit">프레딧 신규회원 가입 이벤트</h3>
        <div class="clfix">
          <span class="per_img">
            <em class="no_img" style="background: #aea9db"><b>배</b></em>
          </span>
          <dl>
            <dt>배슬기 주임 / 경영지원팀</dt>
            <dd>
              2021-05-21 13:21 <span>조회 : <em>25</em></span>
            </dd>
          </dl>
          <em class="re_more"></em>
        </div>
      </div>
      <div class="posting">
        <p><span>게시기간</span><em>영구</em></p>
      </div>
      <div class="add_file nt_file clfix">
        <strong>첨부파일</strong>
        <ul>
          <li class="active">
            <span><img src="../../mobile/img/test_img01.png" alt="" /></span>
            <div>
              <p>IMG2580.png</p>
              <em>(32.52KB)</em>
            </div>
          </li>
          <li class="active">
            <span><img src="../../mobile/img/test_img02.png" alt="" /></span>
            <div>
              <p>
                모바일 SWG 스토리보드_V0.1_2021.03.23(영업부 취합_전자결재
                부문).pptx
              </p>
              <em>(16.03KB)</em>
            </div>
          </li>
        </ul>
      </div>
      <div class="noti_con">
        신규회원 가입 시 추천인 아이디에 SAROM을 입력하여 가입 시 할인 쿠폰을
        받을 수 있습니다.<br />

        더불어 결제 시 사용할 수 있는 적립금을 추가로 받을 수 있으니 많은
        관심바랍니다.
      </div>
      <div class="like_btn">
        <span><em>10</em> LIKE <b></b></span>
      </div>
      <div class="comment">
        <span>댓글 <em>9</em></span>
        <div class="com_input">
          <div class="f_com">
            <textarea placeholder="댓글을 작성해 주세요."></textarea>
            <span class="en_btn">등록</span>
          </div>
        </div>
        <div class="c_com">
          <span class="per_img">
            <em class="no_img" style="background: #aea9db"><b>배</b></em>
          </span>
          <dl>
            <dt>배슬기 주임 / 경영지원팀</dt>
            <dd>2021-05-21 13:21</dd>
          </dl>
          <div class="com_icons">
            <span class="com_ic"></span>
          </div>
          <p>수고하셨습니다. 어려운 상담에 대한 좋은 성과 기대합니다.</p>
          <div class="ccc_com">
            <div class="s_com">
              <textarea placeholder="댓글을 작성해 주세요."></textarea>
              <span class="en_btn">등록</span>
            </div>
          </div>
        </div>
        <div class="cc_com">
          <span class="per_img">
            <em class="no_img" style="background: #bbcbdd"><b>박</b></em>
          </span>
          <dl>
            <dt>박수진 대리 / 마케팅 본부</dt>
            <dd>2021-05-21 13:21</dd>
          </dl>
          <div class="com_icons">
            <span class="com_ic"></span>
          </div>
          <p>좋은말씀 감사합니다. 앞으로도 잘 부탁드리겠습니다.</p>
          <div class="ccc_com">
            <div class="s_com">
              <textarea placeholder="댓글을 작성해 주세요."></textarea>
              <span class="en_btn">등록</span>
            </div>
          </div>
        </div>
        <div class="cc_com">
          <span class="per_img">
            <em class="no_img" style="background: #bcbbdd"><b>박</b></em>
          </span>
          <dl>
            <dt>박미진 선임 / 디자인팀</dt>
            <dd>2021-05-21 13:21</dd>
          </dl>
          <div class="com_icons">
            <span class="com_ic"></span>
            <span class="edit_ic"></span>
            <span class="del_ic"></span>
          </div>
          <p>
            <em>박수진</em>좋은말씀 감사합니다. 앞으로도 잘 부탁드리겠습니다.
          </p>
          <div class="ccc_com">
            <div class="s_com">
              <textarea placeholder="댓글을 작성해 주세요."></textarea>
              <span class="en_btn">등록</span>
            </div>
          </div>
        </div>
        <div class="c_com">
          <span class="per_img">
            <em class="no_img" style="background: #bbddd7"><b>이</b></em>
          </span>
          <dl>
            <dt>이주성 팀장 / 경영지원팀</dt>
            <dd>2021-05-21 13:21</dd>
          </dl>
          <div class="com_icons">
            <span class="com_ic"></span>
          </div>
          <p>수고하셨습니다. 어려운 상담에 대한 좋은 성과 기대 합니다.</p>
          <div class="ccc_com">
            <div class="s_com">
              <textarea placeholder="댓글을 작성해 주세요."></textarea>
              <span class="en_btn">등록</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  methods: {
    Back() {
      this.$router.go(-1);
    },
  },
};
</script>

<style>
</style>