<template>
  <span class="w_cal_btn"><router-link to="write"></router-link></span>
</template>

<script>
export default {
    methods:{
    }

}
</script>

<style>

</style>