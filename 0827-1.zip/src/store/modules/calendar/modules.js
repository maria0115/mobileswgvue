export const dataStore = {
    state: {
        schedule:{
            detail:{
                unid:"",
                where:"month"
            },
        },
        schedulelist:{
            data:[],
            date:{}
        },
    }
}