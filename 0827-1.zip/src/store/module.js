// import config from '../config/key.js';

export const dataStore = {
    state: {
        language: {},  //다국어}
    }
}