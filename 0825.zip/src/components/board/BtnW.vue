<template>
  <span class="w_mail_btn" @click="Path()"><router-link to="/board_more/write"></router-link></span>
</template>

<script>
export default {
  methods: {
    Path(){
      this.$store.commit("boardjs/BoardWritePath",this.path);
    }
  },
  props: {
    path: String,
  },

}
</script>

<style>

</style>