import {
    BoardWrite,Board, BoardDetail
} from '../../../api/index';
import router from '../../../router/index';
//system 모드이면 무슨 light 인지 dark 인지 감지
export default {
    BoardDetail({ state, commit },{menu}){
        var data = {};
        if(menu){
            data.menu = menu;

        }else{
            data.menu = state.store.board.path;

        }
        data.unid = state.store.board.unid;
        console.log(data)
        BoardDetail(data)
        .then((res) => {
            if (res.status !== 200) {
                return false;
            } else {
                console.log(res.data);
                router.push(`/board_more/read`);
                commit("BoardDetailData",res.data)
                return true;
            }
        })

    },
    BoardWrite({ state, commit }, data) {
        BoardWrite(data)
            .then((res) => {
                if (res.status !== 200) {
                    return false;
                } else {
                    router.push(`/board_more/${state.store.board.path}`);
                    // commit("BoardWrite", { menu: type, data: res.data })
                    return true;
                }
            })

    },
    GetBoardList({ state, commit }, { type }) {
        console.log("Get",type)
        console.log(state)
        var data = {};
        data.page = 0;
        data.size = state.board.data[type].size;
        data.boardtype = type;
        Board(data)
            .then((res) => {

                if (res.status !== 200) {
                    return false;
                } else {
                    console.log("GetBoardList", res.data, type)
                    commit("GetBoardList", { menu: type, data: res.data })
                    return true;

                }

            })
    },

}