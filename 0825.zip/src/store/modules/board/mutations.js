export default {
    BoardDetailData(state, data) {
        console.log(data)
        state.store.board.detail = data;
    },
    BoardSaveUnid(state,unid) {
        state.store.board.unid= unid;
    },
    BoardWritePath(state, path) {
        console.log(state)
        state.store.board.path = path;

    },
    GetBoardList(state,{data,menu}){
        state.board.data[menu].data = data;

    },
}