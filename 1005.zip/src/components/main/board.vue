<template>
  <div id="board_tab">
    <div :class="`board01`" v-for="(key, index) in categories" :key="index">
      <strong>{{ key.title }}</strong>
      <ul>
        <li
          :class="{ new: boo(value) }"
          v-for="(value, i) in listOfCategory[key.lnbid]"
          :key="i"
        >
          <a @click="Read(value, key)">{{ value.subject }}</a>
        </li>
      </ul>
      
      <span class="m_more"
        ><router-link
          :to="{
            name: `${key.category}list`,
            params: { lnbid: key.lnbid, type: key.type ,top:top,title:key.title},
          }"
        ></router-link
      ></span>
    </div>
  </div>
</template>

<script>
import { mapState, mapGetters } from "vuex";
export default {
  computed: {
    ...mapGetters("mainjs", ["GetMain"]),
    ...mapGetters("boardjs", ["GetBoard"]),
    ...mapState("mainjs", ["main"]),
    ...mapState(["listOfCategory"]),
  },
  async created() {
    this.top = this.$route.params.lnbid;
    var res = await this.$store.dispatch(
      "CategoryList",
      this.top
    );
    // .then(res=>{
    //   console.log(res,"res.datacreated")
    this.categories = res;
    for (var i = 0; i < res.length; i++) {
      res[i].page = 0;
      res[i].size = 5;
      res[i].category = "board";
      res[i].type = this.$route.params.type;
      this.$store.dispatch("ListOfCategory", res[i]).then((resp) => {
        for (var i = 0; i < res.length; i++) {
          this.listOfCategory[res[i].lnbid] = resp;
        }
        this.$forceUpdate();
      });
    }
    // });
  },
  data() {
    return {
      categories: [],
      top:"",
    };
  },
  methods: {
    Read(value, menu) {
      if (value.unid) {
        this.$store.dispatch("boardjs/BoardDetail", { menu, unid: value.unid });
      }
    },
    boo(value) {
      var moment = require("moment");
      var localTime = moment.utc(value.created).toDate();
      localTime = parseInt(moment(localTime).format("YYYYMMDD"));
      var nowTime = parseInt(moment().format("YYYYMMDD"));
      if (nowTime - localTime < this.main.my.recentdate) {
        return true;
      }
      return false;
    },
  },
};
</script>

<style>
</style>