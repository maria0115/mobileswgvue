<template>
  <span class="w_mail_btn"><router-link :to="{name:'boardwrite'}"></router-link></span>
</template>

<script>
export default {
  methods: {
    
  },
  props: {
    path: String,
  },

}
</script>

<style>

</style>