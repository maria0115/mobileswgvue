<template>
  <div>
    <h2 class="mail_st_header">
      <router-link :to="{name:'seegreet'}">
        <img src="../../mobile/img/wmail_back.png" alt="" /> </router-link
      >인사말 편집
      <div>
        <span class="delet" @click="Delete"><a>삭제</a></span>
        <span class="save" @click="Modify"><a>저장</a></span>
      </div>
    </h2>
    <div class="m_contents06">
      <form>
        <ul>
          <li>
            <span>제목</span>
            <input type="text" v-model="subject" />
          </li>
          <li>
            <span>설정</span>
            <div @click="defaultCheck">
              <em class="sig_check" :class="{ active: this.default }"></em>기본
              인사말로 지정
            </div>
          </li>
          <li>
            <Namo :editor="body" :read="false" ref="editor"></Namo>
            <!-- <textarea contenteditable="true" :value="GetGreetView.body">
안녕하세요 디자인팀 홍길동입니다.
                    </textarea
            > -->
          </li>
        </ul>
      </form>
    </div>
  </div>
</template>

<script>
import { mapState, mapGetters } from "vuex";
import { Editor,EditorContent } from "tiptap";
import Namo from '../editor/namo.vue';
// import EditorContent from "./EditorContent.vue";
export default {
  created() {
    this.default = this.GetGreetView.default;
    this.body = this.GetGreetView.body;
    this.subject = this.GetGreetView.subject;
  },
  mounted() {
    // this.content = this.GetGreetView.body;
    this.editor = new Editor({
      content: this.body,
    })
  },
  beforeDestroy() {
    this.editor.destroy();
  },
  data() {
    return {
      default: false,
      editor: null,
      content: "",
      body: "",
      subject: "",
    };
  },

  computed: {
    ...mapGetters("mailjs",["GetGreetView"]),
  },
  components: {
    EditorContent,Namo
  },
  methods: {
    Delete(){
      this.$store.dispatch("mailjs/SignGreetDelete","greet");
    },
    async Modify() {
      let editorData = this.$refs.editor.$refs.namo.contentWindow.crosseditor.GetBodyValue();
      this.GetGreetView.body = editorData;
      // this.GetGreetView.body = this.editor.getHTML();
      this.GetGreetView.subject = this.subject;
      this.GetGreetView.default = this.default;
      var result = await this.$store.dispatch("mailjs/GreetEdit", this.GetGreetView);
      if(result){
        this.$router.push({ name: "SeeGreet"});
      }
    },
    Back() {
      this.$router.go(-1);
    },
    defaultCheck() {
      this.default = !this.default;
    },
  },
};
</script>

<style>
/* .ProseMirror {
  width: 100%;
  height: 100%;
  resize: none;
  outline: none;
  border: 0;
  padding: 1.25rem;
  font-size: 0.87rem;
  color: #444;
  line-height: 1.6;
  overflow-y: scroll;
} */
</style>