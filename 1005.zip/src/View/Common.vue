<template>
  <div>
    <router-view ></router-view>
    <Footer></Footer>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>