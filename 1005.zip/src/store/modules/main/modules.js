export const dataStore = {
    state: {
        myinfo: {
            info: {
                dept: "",
                name: "",
                position: "",
                photo: ""
            },
            approvalCount: 0,
            mailCount: 0,
            scheduleCount: 0
        },
    }
}