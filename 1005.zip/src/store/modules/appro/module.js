export const dataStore = {
    state: {
        app: {
            unid:"",
            from:"",
        },
    }
}